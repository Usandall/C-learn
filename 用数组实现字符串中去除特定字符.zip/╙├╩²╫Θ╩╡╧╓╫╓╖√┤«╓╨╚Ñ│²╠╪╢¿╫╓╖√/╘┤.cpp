#include<stdio.h>
#include<string.h>
#include<cstring>
int main()
{
    char s[100] = "";
    char a[30];
    
    int l;
    for (l = 0; l < 3; l++)
    {
        gets_s(a);
        strcat_s(s, a);
    }

    printf("%s", s);
}