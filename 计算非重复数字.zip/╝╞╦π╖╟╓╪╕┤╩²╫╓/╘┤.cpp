#include<stdio.h>
int main()
{
	int a[21];
	int i, j, sum;
	sum = 0;
	for (i = 0; i < 20; i++)
	{
		scanf_s("%d", &a[i]);
		for (j = 0; j < i; j++)
		{
			if (a[j] == a[i])
			{
				break;
			}
		}
		if (i == j)
		{
			sum = sum + 1;
		}
	}
	printf("%d", sum);
}