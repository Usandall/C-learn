#include<stdio.h>
int main()
{
	int i, j, n;
	scanf("%d", &n);
	for (i = 0; i <= n; i++)                 //��n+1��  
	{
		for (j = 0; j < n - i; j++)
		{
			printf(" ");
		}
		for (j = 0; j < n + 2 * i - 1; j++)
		{
			printf("*");
		}
		printf("\n");
	}
	for (i = n; i > 0; i--)                      //����n��
	{                                             //��һ�� i=2; j=i=2; �ڶ��� i=1; j=i=1;
		for (j = i; j < n + 1; j++)
		{
			printf(" ");
		}
		for (j = 0; j < 2 * i - 1; j++)                 //��һ�� i=2; �ڶ��� i=1
		{
			printf("*");
		}
		printf("\n");
	}
}