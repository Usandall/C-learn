#include<stdio.h>
int main()
{
	int i, j, u, n, m;
	scanf_s("%d", &m);
	n = m - 1;                                    
	for (i = 1; i <= n + 1; i++)
	{
		for (j = 1; j <= n - i + 1; j++)
		{
			printf(" ");
		}
		for (j = 1; j <= i; j++)
		{
			printf("%d", j);
		}
		for (j = i - 1; j >= 1; j--)
		{
			printf("%d", j);
		}
		printf("\n");
	}
	for (i = n; i >= 1; i--)
	{
		for (j = 1; j <= n - i + 1; j++)
		{
			printf(" ");
		}
		for (j = 1; j <= i; j++)
		{
			printf("%d", j);
		}
		for (j = i - 1; j >= 1; j--)
		{
			printf("%d", j);
		}
		printf("\n");
	}
}