#include<stdio.h>
int main()
{
	int i, j, n;
	scanf_s("%d",&n);
	for (i = 1; i <= n + 1; i++)                
	{
		for (j = 0 ; j < n-i+1; j++)
		{
			printf(" ");
		}
		for (j = 0; j <  2*i -1; j++)                    
		{
			printf("*");
		}
		printf("\n");
	}
	for (i = n; i > 0; i--)                      
	{                                           
		for (j = 0; j < n - i + 1; j++)
		{
			printf(" ");
		}
		for (j = 0; j < 2*i - 1; j++)                
		{
			printf("*");
		}
		printf("\n");
	}
}
